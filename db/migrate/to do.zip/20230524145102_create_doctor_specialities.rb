class CreateDoctorSpecialities < ActiveRecord::Migration[7.0]
  def change
    create_table :doctor_specialities do |t|
      t.belongs_to :doctor, null: false, foreign_key: true
      t.belongs_to :speciality, null: false, foreign_key: true

      t.timestamps
    end
    add_index :doctor_specialities, [:doctor_id, :speciality_id], unique: true
  end
end
